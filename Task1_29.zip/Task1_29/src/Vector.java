import java.util.Scanner;

public class Vector {

    public String name;
    public int x;
    public int y;
    public int z;

    public void setVector() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите название вектора");
        this.name = scanner.nextLine();
        System.out.println("Введите координаты вектора");
        this.x = scanner.nextInt();
        this.y = scanner.nextInt();
        this.z = scanner.nextInt();
    }

    public double getLength() {
        return Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2) + Math.pow(this.z, 2));
    }
}
