public class VOps {

    public static Vector vSum(Vector v1, Vector v2) {
        Vector v3 = new Vector();
        v3.name = "Сумма векторов";
        v3.x = v1.x + v2.x;
        v3.y = v1.y + v2.y;
        v3.z = v1.z + v2.z;
        return v3;
    }

    public static Vector vRaz(Vector v1, Vector v2) {
        Vector v3 = new Vector();
        v3.name = "Разность векторов";
        v3.x = v1.x - v2.x;
        v3.y = v1.y - v2.y;
        v3.z = v1.z - v2.z;
        return v3;
    }

    public static double vScal(Vector v1, Vector v2) {
        return (v1.x * v2.x) + (v1.y * v2.y) + (v1.z * v2.z);
    }

    public static double vVect(Vector v1, Vector v2) {
        return v1.getLength() * v2.getLength() * Math.sqrt(1-Math.pow(VOps.vCos(v1,v2),2));
    }

    public static double vCos(Vector v1, Vector v2) {
        double c;
        c = vScal(v1, v2) / v1.getLength() / v2.getLength();
        return c;
    }

}
