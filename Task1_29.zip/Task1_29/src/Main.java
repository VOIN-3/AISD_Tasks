public class Main {

    public static void main(String[] args) {
        Vector a = new Vector();
        a.setVector();
        Vector b = new Vector();
        b.setVector();

        System.out.println("Длина вектора "+a.name+": "+a.getLength());
        System.out.println("Длина вектора "+b.name+": "+b.getLength());
        System.out.println("Сумма векторов: {"+VOps.vSum(a,b).x+","+VOps.vSum(a,b).y+","+VOps.vSum(a,b).z+"}");
        System.out.println("Разность векторов: {"+VOps.vRaz(a,b).x+","+VOps.vRaz(a,b).y+","+VOps.vRaz(a,b).z+"}");
        System.out.println("Скалярное произведение: "+VOps.vScal(a,b));
        System.out.println("Векторное произведение: "+VOps.vVect(a,b));
        System.out.println("Косинус угла между векторами: "+VOps.vCos(a,b));

    }

}
