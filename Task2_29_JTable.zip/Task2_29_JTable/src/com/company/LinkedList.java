package com.company;

public class LinkedList {
    private Node head;

    public LinkedList() {
        head = null;
    }

    public class Node {
        public int data;
        public Node next;

        public Node(int data) {
            this.data=data;
            next=null;
        }
    }

    public void add(int data) {
        Node newNode = new Node(data);
        Node currentNode = head;

        if (head == null) {
            head = newNode;
        } else {
            while (currentNode.next!=null) {
                currentNode=currentNode.next;
            }
            currentNode.next = newNode;
        }
    }

    public int[] sort(int[] arr) {
        boolean flag = true;

        while (flag) {
            Node n = head;
            flag = false;
            while (n.next != null) {
                if (n.data > n.next.data) {
                    swap(n, n.next);
                    flag = true;
                }
                n = n.next;
            }
        }

        Node n = head;
        int i = 0;
        while(n != null) {
            arr[i]=n.data;
            n=n.next;
            i++;
        }

        return arr;
    }

    private void swap(Node n1, Node n2) {
        int n = n1.data;
        n1.data = n2.data;
        n2.data = n;
    }

}