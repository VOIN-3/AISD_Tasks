package com.company;


public class Task {
    public static void Process(int[] arr) {
        arr = SortLinkedList(arr);
    }

    public static int[] SortLinkedList(int[] arr) {
        LinkedList list = new LinkedList();
        for(int i=0; i<arr.length; i++) {
            list.add(arr[i]);
        }
        arr=list.sort(arr);
        return arr;
    }
}
