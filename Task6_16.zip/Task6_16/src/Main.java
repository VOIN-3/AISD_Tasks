import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Main {

    public static boolean matches(char ch) { //Проверяем символ на заглавный
        String  chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИКЛМНОПРСТУФЦЧШЩЪЫЬЭЮЯ";
        for (int i=0; i<chars.length(); i++) {
            if (ch == chars.charAt(i)) {
                return true;
            }
        }
        return false;
    }

    public static boolean notPrep(char ch) { //Выбрасываем из найденного слова знаки препинания
        String  chars = ".!?:;";
        for (int i=0; i<chars.length(); i++) {
            if (ch == chars.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public static void main(String args[]) throws IOException {
        HashMap<String, Integer> map = new HashMap<>();

        //Это все чтение файла
        File file = new File("input1.txt");
        FileReader reader = new FileReader(file);
        char [] ch = new char[(int) file.length()];
        reader.read(ch);
        reader.close();
        System.out.println(ch);

        String word ="";
        int c = 0;

        for(int i=1; i<ch.length; i++) { //Считаем со второго символа чтобы сразу же вычесть первое слово в предложении
            if (matches(ch[i]) && notPrep(ch[i-1]) && notPrep(ch[i-2]) ) { //Находим слово с заглавной буквы
                while(notPrep(ch[i]) && ch[i]!=' ') { //Записываем слово
                    word+=ch[i];
                    i+=1;
                    if (i==ch.length) {
                        break;
                    }
                }
                if(!map.containsKey(word)) { //Добавляем слово в хеш-таблицу
                    map.put(word, 1);
                } else { //Если слово уже существует, добавляем к данных таблицы единицу
                    c = map.get(word).intValue();
                    map.replace(word, c+1);
                }
                word = ""; //Чистим слово
            }
        }
        System.out.println(map);
    }

}
