public class Main {

    public static void main(String[] args) {
        int[] data = { 7, 10, 3, 8, 7, 2, 1, 9, 5, 7 };
        boolean[] fixed = { false, true, false, false, true, true, false, false, true, false };
        data=sort(data, fixed);
        for(int i=0; i<data.length; i++) {
            System.out.print(data[i]+" ");
        }
    }

    public static int[] sort(int[] data, boolean[] fixed) {

        for (int i = 0; i < data.length; i++) {
            int curr = i;
            int min = data[i];

            for (int j = i + 1; j < data.length; j++) {
                if ((data[j] < min) && !(fixed[i]) && !(fixed[j])) {
                    curr = j;
                    min = data[j];
                }
            }

            data[curr] = data[i];
            data[i] = min;
        }

        return data;
    }

}
