package com.company;

import java.awt.EventQueue;
import java.util.Locale;
import javax.swing.UIManager;
import com.company.SwingUtils;

public class Program {

    public static void main(String args[]) throws Exception {
        Locale.setDefault(Locale.ROOT);
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        SwingUtils.setDefaultFont("Microsoft Sans Serif", 16);

        EventQueue.invokeLater(() -> {
            new MainJFrame().setVisible(true);
        });
    }
}
