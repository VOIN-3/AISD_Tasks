package com.company;

import java.util.ArrayDeque;

public class Task {

    public static void task(int n) {
        ArrayDeque<ArrayDeque<Integer>> deque = new ArrayDeque<ArrayDeque<Integer>>();
        for (int i = 1; i <= n; i++) {
            ArrayDeque<Integer> sub = new ArrayDeque<Integer>();
            for(int j=1; j<=i; j++) {
                sub.addLast(j);
            }
            deque.addLast(sub);
        }
        System.out.println(deque);
    }
}
