import java.util.Random;
import java.util.Scanner;

public class Main {

    public static BinaryTree task(BinaryTree tree) {
        Node curr = tree.root;
        while((curr.left != null) && (curr.right != null)) {
            curr = curr.right;
        }
        curr.right.right = tree.root.left;
        tree.root.left = null;
        return tree;
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree(1);

        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.right.right = new Node(6);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);

        tree = task(tree);

        tree.printTree();
    }
}